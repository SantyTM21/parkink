<?php

include('config.php');

$respuesta = "";
$post = json_decode(file_get_contents('php://input'), true);

if ($post['accion'] == 'loginCheck') {
    $user = mysqli_real_escape_string($mysqli, $post['user']);
    $clave = mysqli_real_escape_string($mysqli, $post['clave']);
    $sentencia = "SELECT * FROM garage WHERE ruc_garage = '$user' ";

    $result = mysqli_query($mysqli, $sentencia);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $datos[] = array(
            "id_garage" => $row['id_garage'],
            "user" => $row['ruc_garage'],
            "nombre" => $row['nombre_garage'],
            "direccion" => $row['direccion_garage']
        );

        if ($row['estado_bloqueo_garage'] == 1) {
            $respuesta = json_encode(array('mensaje' => 'Cuenta de garage bloqueada'));
        } else if ($row['clave_garage'] == $clave && $row['estado_bloqueo_garage'] == 0) {
            $respuesta = json_encode(array('estado' => true, 'garage' => $datos, 'mensaje' => 'Credenciales correctas para garage'));
        } else if ($row['clave_garage'] != $clave && $row['estado_bloqueo_garage'] == 0) {
            $respuesta = json_encode(array('mensaje' => 'Clave incorrecta para garage'));
        }
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'RUC de garage incorrecto'));
    }
    echo $respuesta;
}

if ($post['accion'] == 'listarSlots') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id_garage']);
    $sentencia = "SELECT slot_carro_garage, slot_carro_libre_garage, slot_moto_garage, slot_moto_libre_garage, valor_hora_garage FROM garage WHERE id_garage = $id_garage";

    $result = mysqli_query($mysqli, $sentencia);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $slots_carros = array(
            "total" => $row['slot_carro_garage'],
            "libres" => $row['slot_carro_libre_garage']
        );

        $slots_motos = array(
            "total" => $row['slot_moto_garage'],
            "libres" => $row['slot_moto_libre_garage']
        );

        $valor_hora = $row['valor_hora_garage'];

        $respuesta = json_encode(array('estado' => true, 'carros' => $slots_carros, 'motos' => $slots_motos, 'valor_hora' => $valor_hora));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => "No existen slots para este garage"));
    }

    echo $respuesta;
}

if ($post['accion'] == 'obtenerGarage') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id_garage']);

    $sentencia = "SELECT * FROM garage WHERE id_garage = '$id_garage'";
    $result = mysqli_query($mysqli, $sentencia);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $datos_garage = array(
            "id_garage" => $row['id_garage'],
            "ruc_garage" => $row['ruc_garage'],
            "nombre_garage" => $row['nombre_garage'],
            "slot_carro_garage" => $row['slot_carro_garage'],
            "slot_carro_libre_garage" => $row['slot_carro_libre_garage'],
            "slot_moto_garage" => $row['slot_moto_garage'],
            "slot_moto_libre_garage" => $row['slot_moto_libre_garage'],
            "clave_garage" => $row['clave_garage'],
            "valor_hora" => $row['valor_hora_garage'],
            "direccion" => $row['direccion_garage'],
            "estado_bloqueo_garage" => $row['estado_bloqueo_garage']
        );

        $respuesta = json_encode(array('estado' => true, 'garage' => $datos_garage));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'No se encontró el garage con el ID especificado'));
    }
    echo $respuesta;
}

if ($post['accion'] == 'actualizarGarage') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id']);
    $nombre_garage = mysqli_real_escape_string($mysqli, $post['nombre']);
    $valor_hora_garage = mysqli_real_escape_string($mysqli, $post['valor_hora']);
    $slot_carro_garage = mysqli_real_escape_string($mysqli, $post['slot_carros']);
    $clave_garage = mysqli_real_escape_string($mysqli, $post['clave']);
    $direccion_garage = mysqli_real_escape_string($mysqli, $post['direccion']);

    $sentencia = "UPDATE garage SET nombre_garage = '$nombre_garage', valor_hora_garage = '$valor_hora_garage', slot_carro_garage = '$slot_carro_garage', clave_garage = '$clave_garage', direccion_garage = '$direccion_garage' WHERE id_garage = '$id_garage'";

    if (mysqli_query($mysqli, $sentencia)) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Datos del garage actualizados correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al actualizar los datos del garage'));
    }

    echo $respuesta;
}

if ($post['accion'] == 'eliminarGarage') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id']);

    $sentencia = "DELETE FROM garage WHERE id_garage = '$id_garage'";

    if (mysqli_query($mysqli, $sentencia)) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Garage eliminado correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al eliminar el garage'));
    }

    echo $respuesta;
}

if ($post['accion'] == 'eliminarTickets') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id']);

    $sentenciaEliminarTickets = "DELETE FROM ticket WHERE id_garage_ticket = '$id_garage'";
    $resultEliminarTickets = mysqli_query($mysqli, $sentenciaEliminarTickets);
    $sentenciaActualizarSlots = "UPDATE garage SET slot_carro_libre_garage = slot_carro_garage WHERE id_garage = '$id_garage'";
    $resultActualizarSlots = mysqli_query($mysqli, $sentenciaActualizarSlots);
    if ($resultEliminarTickets) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Registros de tickets eliminados y slots libres actualizados correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al eliminar los registros de tickets o actualizar los slots libres'));
    }

    echo $respuesta;
}

if ($post['accion'] == 'crearGarage') {
    $ruc = mysqli_real_escape_string($mysqli, $post['ruc']);
    $nombre_garage = mysqli_real_escape_string($mysqli, $post['nombre_garage']);
    $slot_carro = mysqli_real_escape_string($mysqli, $post['slot_carro']);
    $clave1 = mysqli_real_escape_string($mysqli, $post['clave1']);
    $valor_hora = mysqli_real_escape_string($mysqli, $post['valor_hora']);
    $direccion = mysqli_real_escape_string($mysqli, $post['direccion']);
    $correo = mysqli_real_escape_string($mysqli, $post['correo']);

    $sentencia = "INSERT INTO garage (ruc_garage, nombre_garage, slot_carro_garage, slot_carro_libre_garage, clave_garage, valor_hora_garage, direccion_garage, correo_garage) 
    VALUES ('$ruc', '$nombre_garage', '$slot_carro', '$slot_carro', '$clave1', '$valor_hora', '$direccion', '$correo')";

    if (mysqli_query($mysqli, $sentencia)) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Garage ingresado correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al ingresar el garage'));
    }

    echo $respuesta;
}

if ($post['accion'] == 'recuperarClave') {
    $ruc = mysqli_real_escape_string($mysqli, $post['ruc']);
    $sentencia = "SELECT clave_garage FROM garage WHERE ruc_garage = '$ruc'";

    $result = mysqli_query($mysqli, $sentencia);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $clave = $row['clave_garage'];
        $respuesta = json_encode(array('estado' => true, 'clave' => $clave));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => "No se encontró el garage con el RUC especificado"));
    }
    echo $respuesta;
}



if ($post['accion'] == 'desbloquearCuenta') {
    $ruc = mysqli_real_escape_string($mysqli, $post['ruc']);
    $correo = mysqli_real_escape_string($mysqli, $post['correo']);

    $sentenciaVerificar = "SELECT * FROM garage WHERE ruc_garage = '$ruc' AND correo_garage = '$correo'";
    $resultVerificar = mysqli_query($mysqli, $sentenciaVerificar);

    if ($resultVerificar && mysqli_num_rows($resultVerificar) > 0) {

        $sentenciaDesbloquear = "UPDATE garage SET estado_bloqueo_garage = 0 WHERE ruc_garage = '$ruc' AND correo_garage = '$correo'";
        $resultDesbloquear = mysqli_query($mysqli, $sentenciaDesbloquear);

        if ($resultDesbloquear) {
            $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Cuenta desbloqueada correctamente'));
        } else {
            $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al desbloquear cuenta'));
        }
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'No se encontró el garage con el RUC y correo especificados'));
    }

    echo $respuesta;
}


if ($post['accion'] == 'bloquearCuenta') {
    $ruc = mysqli_real_escape_string($mysqli, $post['ruc']);

    $sentenciaBloquear = "UPDATE garage SET estado_bloqueo_garage = 1 WHERE ruc_garage = '$ruc'";
    $resultBloquear = mysqli_query($mysqli, $sentenciaBloquear);

    if ($resultBloquear) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Cuenta bloqueada correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al bloquear cuenta'));
    }

    echo $respuesta;
}

if ($post['accion'] == 'verificarRUC') {
    $ruc = intval($post['ruc']);


    $sentencia = sprintf("SELECT * FROM garage WHERE ruc_garage = %d", $ruc);
    $result = mysqli_query($mysqli, $sentencia);

    if (mysqli_num_rows($result) > 0) {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => "RUC inválido, ya existe en la base de datos"));
    } else {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => "RUC válido"));
    }

    echo $respuesta;
}
