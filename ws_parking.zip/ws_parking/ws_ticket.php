<?php

include('config.php');

$respuesta = "";
$post = json_decode(file_get_contents('php://input'), true);

if ($post['accion'] == 'listarTicketsNuevos') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id_garage']);
    $sentencia = "SELECT * FROM ticket WHERE id_garage_ticket = $id_garage AND valor_total_ticket = 0";

    $result = mysqli_query($mysqli, $sentencia);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $datos[] = array(
                "id_ticket" => $row['id_ticket'],
                "cliente" => $row['cliente_ticket'],
                "placa" => $row['placa_ticket'],
                "modelo" => $row['modelo_ticket'],
                "hora_entrada" => $row['hora_entrada_ticket'],
            );
        }
        $respuesta = json_encode(array('estado' => true, 'tickets' => $datos));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => "No existen tickets para este garage"));
    }
    echo $respuesta;
}
if ($post['accion'] == 'listarTicketsPagados') {
    $id_garage = mysqli_real_escape_string($mysqli, $post['id_garage']);
    $sentencia = "SELECT * FROM ticket WHERE id_garage_ticket = $id_garage AND valor_total_ticket != 0";

    $result = mysqli_query($mysqli, $sentencia);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $datos[] = array(
                "id_ticket" => $row['id_ticket'],
                "cliente" => $row['cliente_ticket'],
                "placa" => $row['placa_ticket'],
                "modelo" => $row['modelo_ticket'],
                "hora_entrada" => $row['hora_entrada_ticket'],
                "hora_salida" => $row['hora_salida_ticket'],
                "valor_total" => $row['valor_total_ticket']
            );
        }
        $respuesta = json_encode(array('estado' => true, 'tickets' => $datos));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => "No existen tickets para este garage"));
    }
    echo $respuesta;
}
// if ($post['accion'] == 'obtenerTicket') {
//     $id_ticket = mysqli_real_escape_string($mysqli, $post['id_ticket']);
//     $sentencia = "SELECT * FROM ticket WHERE id_ticket = $id_ticket";

//     $result = mysqli_query($mysqli, $sentencia);
//     if (mysqli_num_rows($result) > 0) {
//         while ($row = mysqli_fetch_array($result)) {
//             $datos[] = array(
//                 "id_ticket" => $row['id_ticket'],
//                 "cliente" => $row['cliente_ticket'],
//                 "placa" => $row['placa_ticket'],
//                 "modelo" => $row['modelo_ticket'],
//                 "hora_entrada" => $row['hora_entrada_ticket'],
//                 "hora_salida" => $row['hora_salida_ticket'],
//                 "valor_total" => $row['valor_total_ticket']
//             );
//         }
//         $respuesta = json_encode(array('estado' => true, 'ticket' => $datos));
//     } else {
//         $respuesta = json_encode(array('estado' => false, 'mensaje' => "No existen este ticket "));
//     }
//     echo $respuesta;
// }


if ($post['accion'] == 'obtenerTicket') {
    $id_ticket = mysqli_real_escape_string($mysqli, $post['id_ticket']);
    $sentencia = "SELECT * FROM ticket WHERE id_ticket = $id_ticket";

    $result = mysqli_query($mysqli, $sentencia);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $datos_ticket = array(
            "id_ticket" => $row['id_ticket'],
            "cliente" => $row['cliente_ticket'],
            "placa" => $row['placa_ticket'],
            "modelo" => $row['modelo_ticket'],
            "hora_entrada" => $row['hora_entrada_ticket'],
            "hora_salida" => $row['hora_salida_ticket'],
            "valor_total" => $row['valor_total_ticket']
        );

        $respuesta = json_encode(array('estado' => true, 'ticket' => $datos_ticket));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => "No se encontró el ticket solicitado"));
    }

    echo $respuesta;
}

if ($post['accion'] == 'setCobro') {
    $placa = mysqli_real_escape_string($mysqli, $post['placa']);
    $hora_salida = mysqli_real_escape_string($mysqli, $post['hora_salida']);
    $valor_total = mysqli_real_escape_string($mysqli, $post['valor_total']);
    $id_garage = mysqli_real_escape_string($mysqli, $post['id_garage']);

    $sentencia = "UPDATE ticket SET hora_salida_ticket = '$hora_salida', valor_total_ticket = $valor_total WHERE placa_ticket = '$placa'";
    $sentenciaSlot = "UPDATE garage SET slot_carro_libre_garage = slot_carro_libre_garage + 1 WHERE id_garage = '$id_garage'";
    $result = mysqli_query($mysqli, $sentencia);
    $resultSlot = mysqli_query($mysqli, $sentenciaSlot);

    if ($result) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Ticket cobrado correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al cobrar el ticket'));
    }

    echo $respuesta;
}

if ($post['accion'] == 'crearTicket') {
    $cliente = mysqli_real_escape_string($mysqli, $post['cliente']);
    $placa = mysqli_real_escape_string($mysqli, $post['placa']);
    $modelo = mysqli_real_escape_string($mysqli, $post['modelo']);
    $hora_entrada = mysqli_real_escape_string($mysqli, $post['horaEntrada']);
    $id_garage = mysqli_real_escape_string($mysqli, $post['id_garage']);

    $sentenciaSlot = "UPDATE garage SET slot_carro_libre_garage = slot_carro_libre_garage - 1 WHERE id_garage = '$id_garage'";
    $resultSlot = mysqli_query($mysqli, $sentenciaSlot);

    $sentencia = "INSERT INTO ticket (cliente_ticket, placa_ticket, modelo_ticket, hora_entrada_ticket, id_garage_ticket) 
    VALUES ('$cliente', '$placa', '$modelo', '$hora_entrada', '$id_garage')";

    if (mysqli_query($mysqli, $sentencia)) {
        $respuesta = json_encode(array('estado' => true, 'mensaje' => 'Ticket ingresado correctamente'));
    } else {
        $respuesta = json_encode(array('estado' => false, 'mensaje' => 'Error al ingresar el ticket'));
    }

    echo $respuesta;
}
