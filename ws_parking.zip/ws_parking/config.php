<?php
define('db', 'db_parking');
define('usuario', 'root');
define('clave', '');
define('host', 'localhost');

$mysqli = new mysqli(host, usuario, clave, db);
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header('Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Request-With, x-xsrf-token');
header('Content-Type: application/json: charset=utf-8');
