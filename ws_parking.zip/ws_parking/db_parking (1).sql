-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-03-2024 a las 19:53:46
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_parking`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `garage`
--

CREATE TABLE `garage` (
  `id_garage` int(11) NOT NULL,
  `ruc_garage` int(11) DEFAULT NULL,
  `nombre_garage` varchar(45) DEFAULT NULL,
  `slot_carro_garage` int(11) DEFAULT 0,
  `slot_carro_libre_garage` int(11) DEFAULT 0,
  `slot_moto_garage` int(11) DEFAULT 0,
  `slot_moto_libre_garage` int(11) DEFAULT 0,
  `clave_garage` varchar(45) DEFAULT NULL,
  `correo_garage` varchar(50) NOT NULL DEFAULT 'example@mail.com',
  `valor_hora_garage` float DEFAULT 0,
  `direccion_garage` varchar(255) DEFAULT NULL,
  `estado_bloqueo_garage` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `garage`
--

INSERT INTO `garage` (`id_garage`, `ruc_garage`, `nombre_garage`, `slot_carro_garage`, `slot_carro_libre_garage`, `slot_moto_garage`, `slot_moto_libre_garage`, `clave_garage`, `correo_garage`, `valor_hora_garage`, `direccion_garage`, `estado_bloqueo_garage`) VALUES
(1, 123456789, 'Garaje A', 50, 20, 30, 10, 'clave123', 'example@mail.com', 1.5, 'Calle 123, Ciudad X', 0),
(2, 987654321, 'Garaje B', 80, 40, 20, 5, 'clave456', 'example@mail.com', 1, 'Avenida Principal, Ciudad Y', 1),
(4, 123, 'Garage Pedrin', 3, 3, 0, 0, '123', '123@mail.com', 1, '123', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ticket`
--

CREATE TABLE `ticket` (
  `id_garage_ticket` int(11) DEFAULT NULL,
  `id_ticket` int(11) NOT NULL,
  `cliente_ticket` varchar(100) DEFAULT NULL,
  `placa_ticket` varchar(10) DEFAULT NULL,
  `modelo_ticket` varchar(45) DEFAULT NULL,
  `hora_entrada_ticket` time DEFAULT NULL,
  `hora_salida_ticket` time DEFAULT NULL,
  `valor_total_ticket` float DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ticket`
--

INSERT INTO `ticket` (`id_garage_ticket`, `id_ticket`, `cliente_ticket`, `placa_ticket`, `modelo_ticket`, `hora_entrada_ticket`, `hora_salida_ticket`, `valor_total_ticket`) VALUES
(1, 1, 'Cliente 1', 'ABC123', 'Toyota Corolla', '09:00:00', '12:00:00', 0),
(2, 2, 'Cliente 2', 'DEF456', 'Honda Civic', '10:30:00', '14:45:00', 0),
(1, 4, 'Cliente 4', 'JKL012', 'Chevrolet Spark', '08:45:00', '11:30:00', 0),
(2, 5, 'Cliente 5', 'MNO345', 'Nissan Sentra', '12:00:00', '15:00:00', 0),
(1, 7, 'Cliente 7', 'STU901', 'Hyundai Elantra', '10:00:00', '14:00:00', 0),
(2, 8, 'Cliente 8', 'VWX234', 'Mazda CX-5', '11:45:00', '15:45:00', 0),
(1, 10, 'Cliente 10', 'BCD890', 'Mercedes-Benz C-Class', '09:15:00', '13:30:00', 0),
(NULL, 11, 'paco', 'tba-0214', 'corza verde', '00:00:00', NULL, NULL),
(NULL, 13, 'paco', 'tba-0215', 'corza verde', '16:13:48', NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `garage`
--
ALTER TABLE `garage`
  ADD PRIMARY KEY (`id_garage`);

--
-- Indices de la tabla `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id_ticket`),
  ADD KEY `ondelete` (`id_garage_ticket`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `garage`
--
ALTER TABLE `garage`
  MODIFY `id_garage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id_ticket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ondelete` FOREIGN KEY (`id_garage_ticket`) REFERENCES `garage` (`id_garage`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
